# IT2120 Lab 05 - Exercise
getwd()
setwd("C:\\Users\\IT24103806\\Desktop\\IT24103806")

# Q1
delivery <- read.table("Exercise - Lab 05.txt", header = TRUE)
delivery_times <- delivery[[1]]

# Q1 (output)
print(head(delivery_times))
cat("N =", length(delivery_times), "\n")
cat("Mean =", mean(delivery_times), "\n")
cat("Median =", median(delivery_times), "\n")
cat("SD =", sd(delivery_times), "\n")

# Q2
breaks <- seq(20, 70, length.out = 10)
hist(delivery_times, breaks = breaks, right = FALSE,
     main = "Histogram of Delivery Times (9 classes, [20,70) intervals)",
     xlab = "Delivery Time (minutes)", ylab = "Frequency")
#Q3
#Distribution is approximately symmetric and unimodal; peak in the middle class, no heavy tails.

# Q4
upper_bounds <- breaks[-1]
cumfreq <- freq_table$CumFreq
plot(upper_bounds, cumfreq, type = "b", pch = 16,
     main = "Ogive (Cumulative Frequency Polygon)",
     xlab = "Delivery Time (upper class boundaries)",
     ylab = "Cumulative Frequency")